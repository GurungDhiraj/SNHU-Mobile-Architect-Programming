package com.zybooks.projecttwo;

import android.os.Bundle;
//import android.widget.ImageButton;
import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.widget.Switch;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SettingsActivity extends AppCompatActivity {
    private static final int smsRequestCode = 101;
    private Switch smsNotificationSwitch;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sharedPreferences = getSharedPreferences("AppSettings", MODE_PRIVATE);
        smsNotificationSwitch = findViewById(R.id.smsNotificationSwitch);

        boolean enableSMS = sharedPreferences.getBoolean("SMS_Enabled", false);
        smsNotificationSwitch.setChecked(enableSMS);

        smsNotificationSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {

            if (isChecked) {
                // Check and request permission if turning ON
                if (ContextCompat.checkSelfPermission(SettingsActivity.this, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(SettingsActivity.this, new String[]{Manifest.permission.RECEIVE_SMS}, smsRequestCode);
                }
                else {
                    // Save permission granted preference
                    saveSmsPreference(true);
                }
            }
            else {
                // Save permission NOT granted preference
                saveSmsPreference(false);
            }

        });
    }
    private void saveSmsPreference(boolean isEnabled){
        sharedPreferences.edit().putBoolean("SMS_Enabled", isEnabled).apply();
        Toast.makeText(this, "SMS notifications " + (isEnabled ? "enabled" : "disabled"), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int request, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(request, permissions, grantResults);
        if (request == smsRequestCode) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSmsPreference(true);
            }
            else {
                // Permission denied so disable preference
                smsNotificationSwitch.setChecked(false);
                saveSmsPreference(false);
                Toast.makeText(this, "SMS permission denied.", Toast.LENGTH_LONG).show();
            }
        }
    }
}