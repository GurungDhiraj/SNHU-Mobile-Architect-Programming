package com.zybooks.projecttwo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;
import android.telephony.SmsMessage;
import android.provider.Telephony;
import androidx.core.app.NotificationCompat;
public class SMSNotificationReceiver extends BroadcastReceiver {

    private static final String channelID = "Inventory App Channel";

    @Override
    public void onReceive(Context context, Intent intent) {
        boolean isSmsEnabled = context.getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
                .getBoolean("SMS_Enabled", false);
        if (!isSmsEnabled) return;

        if (Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) {
            SmsMessage[] messages = Telephony.Sms.Intents.getMessagesFromIntent(intent);

            for (SmsMessage currentMessage : messages) {
                String sender = currentMessage.getDisplayOriginatingAddress();
                String messageBody = currentMessage.getDisplayMessageBody();
                showNotification(context, sender, messageBody);
            }
        }
    }

    private void showNotification(Context context, String sender, String message) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Create notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelID,
                    "Inventory Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            notificationManager.createNotificationChannel(channel);
        }

        Intent notificationIntent = new Intent(context, InventoryActivity.class);
        notificationIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Display notification
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, channelID)
                .setSmallIcon(R.drawable.ic_settings)
                .setContentTitle("New SMS from " + sender)
                .setContentText(message)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        notificationManager.notify(0, notificationBuilder.build());

    }
}
