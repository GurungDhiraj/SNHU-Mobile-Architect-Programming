package com.zybooks.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton addButton;
    ImageButton settingsButton;

    InventoryDatabaseHelper myDB;

    ArrayList<String> item_name, item_ID, item_amount;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        settingsButton = findViewById(R.id.settingsButton);

        // On Click Listener for the floating action button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, AddInventoryActivity.class);
                startActivity(intent);
            }
        });

        // On Click Listener for the Settings button on the header
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryActivity.this, SettingsActivity.class);
                startActivity(intent);
            }
        });

        myDB = new InventoryDatabaseHelper(InventoryActivity.this);
        item_name = new ArrayList<>();
        item_ID = new ArrayList<>();
        item_amount = new ArrayList<>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(InventoryActivity.this,InventoryActivity.this, item_name, item_ID, item_amount);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(InventoryActivity.this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1){
            recreate();
        }
    }

    public void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();

        if(cursor.getCount() == 0){
            Toast.makeText(this, "No Data.", Toast.LENGTH_SHORT).show();
        }
        else{
            while(cursor.moveToNext()){
                //item_name.add(cursor.getString(0));
                //item_ID.add(cursor.getString(1));
                //item_amount.add(cursor.getString(2));
                item_name.add(cursor.getString(cursor.getColumnIndexOrThrow("Item_Name")));
                item_ID.add(cursor.getString(cursor.getColumnIndexOrThrow("id")));
                item_amount.add(cursor.getString(cursor.getColumnIndexOrThrow("Item_Amount")));
            }
        }
    }
}