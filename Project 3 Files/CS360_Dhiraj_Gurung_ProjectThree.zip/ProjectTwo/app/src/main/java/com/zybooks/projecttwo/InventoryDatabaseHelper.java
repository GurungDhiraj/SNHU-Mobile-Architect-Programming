package com.zybooks.projecttwo;


import static android.app.DownloadManager.COLUMN_TITLE;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class InventoryDatabaseHelper extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME = "Inventory.db";
    private static  final int DATABASE_VERSION = 1;
    private static final String TABLE_NAME = "Inventory";
    private static final String COLUMN_NAME = "Item_Name";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_AMOUNT = "Item_Amount";
    InventoryDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query =
                "CREATE TABLE " + TABLE_NAME +
                        " (" + COLUMN_NAME + " TEXT, " +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_AMOUNT + " FLOAT);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public void addItem(String name,int ID, float amount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_NAME, name);
        cv.put(COLUMN_ID, ID);
        cv.put(COLUMN_AMOUNT, amount);
        long result = db.insert(TABLE_NAME, null, cv);

        // Output for when Data fails to insert
        if(result == -1){
            Toast.makeText(context, "Insert Data Failed", Toast.LENGTH_SHORT).show();
        }
        // Output for when Data successfully inserts
        else{
            Toast.makeText(context, "Data Successfully Added", Toast.LENGTH_SHORT).show();
        }
    }

    Cursor readAllData() {
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null){
            cursor = db.rawQuery(query, null);
        }

        return cursor;
    }

    void updateData(String name, String id, String amount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_NAME, name);
        //cv.put(COLUMN_ID, id);
        cv.put(COLUMN_AMOUNT, Float.parseFloat(amount));

        long result = db.update(TABLE_NAME, cv, "id=?", new String[]{id});
        if(result == 0){
            Toast.makeText(context, "Failed to Update.", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Successfully Updated!", Toast.LENGTH_SHORT).show();

        }

    }

    void deleteOneRow(String id){
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, "id=?", new String[]{id});

        if(result == 0){
            Toast.makeText(context, "Failed to Delete.", Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(context, "Successfully Deleted", Toast.LENGTH_SHORT).show();
        }
    }
}
